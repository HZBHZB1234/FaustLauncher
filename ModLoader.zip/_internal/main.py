import atexit
import signal
import subprocess
import sys
import tempfile

# Needed for embedded python
import os
import logging

class SteamLauncher:
    def __init__(self):
        self.steam_paths = [
            r"C:\Program Files (x86)\Steam\steam.exe",
            r"C:\Program Files\Steam\steam.exe",
            os.path.expanduser(r"~\Steam\steam.exe")
        ]
    
    def find_steam_path(self):
        """查找Steam安装路径"""
        for path in self.steam_paths:
            if os.path.exists(path):
                return path
        return None
    
    def launch_game(self, game_id, wait_for_steam=True):
        """
        启动Steam游戏
        
        Args:
            game_id: Steam游戏ID
            wait_for_steam: 是否等待Steam启动
        """
        # 方法1: 使用URL协议（最简单）
        try:
            steam_url = f"steam://rungameid/{game_id}"
            if os.name == 'nt':  # Windows
                subprocess.Popen(['start', steam_url], shell=True)
            else:  # Linux/macOS
                subprocess.Popen(['xdg-open', steam_url])
            print(f"✅ 通过URL协议启动游戏ID: {game_id}")
            return True
        except Exception as e:
            print(f"❌ URL协议启动失败: {e}")
        
        print("❌ 所有启动方法都失败了")
        return False

# DO NOT IMPORT ANY FILES BEFORE THESE TWO LINES
file_dir = os.path.dirname(__file__)
sys.path.append(file_dir)

from modfolder import get_mod_folder
import patch
import sound

mod_zips_root_path = get_mod_folder()
os.makedirs(mod_zips_root_path, exist_ok=True)


if len(sys.argv) < 2:
    logging.info("Usage: main.py <game_path>")
    sys.exit(1)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(os.path.join(mod_zips_root_path, "log.txt")),
        logging.StreamHandler(stream=sys.stdout)
    ]
)

logging.info("Limbus Mod Loader version: v1.8")


def kill_handler(*args) -> None:
    sys.exit(0)


def cleanup_assets():
    try:
        logging.info("Cleaning up assets")
        patch.cleanup_assets()
        sound.restore_sound()
    except Exception as e:
        logging.error("Error: %s", e)

try:
    logging.info("Limbus args: %s", sys.argv)
    cleanup_assets()
    atexit.register(cleanup_assets)
    signal.signal(signal.SIGINT, kill_handler)
    signal.signal(signal.SIGTERM, kill_handler)

    logging.info("Detecting lunartique mods")
    patch.detect_lunartique_mods(mod_zips_root_path)
    tmp_asset_root = tempfile.mkdtemp()
    logging.info("Extracting mod assets to %s", tmp_asset_root)
    patch.extract_assets(tmp_asset_root, mod_zips_root_path)
    logging.info("Backing up data and patching assets....")
    patch.patch_assets(tmp_asset_root)
    patch.shutil.rmtree(tmp_asset_root)
    sound.replace_sound(mod_zips_root_path)
    logging.info("Starting game")

    # launcher = SteamLauncher()
    # success = launcher.launch_game(1793530)  # Limbus Company game ID

    # if not success:
    #     pass


    subprocess.Popen(sys.argv[1], shell=True)

except Exception as e:
    logging.error("Error: %s", e)
    sys.exit(1)